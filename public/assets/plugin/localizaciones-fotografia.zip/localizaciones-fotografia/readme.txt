=== Plugin Name ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: http://www.subexpuesta.com/donaciones
Tags: localizaciones, fotografia, subexpuesta, mapa, mapa con localizaciones
Requires at least: 3.0.1
Tested up to: 4.2.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Inserta en tu web todas las localizaciones que tengas subidas en www.subexpuesta.com

== Description ==

Inserta en tu web de una manera rápida y sencillas todas aquellas localizaciones que has idos subiendo a la web de www.subexpuesta.com


== Installation ==


1. Instala el plugin y actívalo
2. Entra en el apartado Ajustes -> Lectura
3. Ahí encontrarás para configurar el plugin, con el usuario y el nivel de zoom que quieres
4. En la lugar donde quieras insertar el mapa inserta este código: [subexpuesta width="600" height="350"][/subexpuesta]
5. Elige del código anterior el ancho y el alto del mapa (se recomienda un mapa grande)


== Changelog ==

= 0.1 =
* Introduce tu usuario y obten todas tus localizaciones
* Configura el ancho, el alto y el zoom del mapa.

